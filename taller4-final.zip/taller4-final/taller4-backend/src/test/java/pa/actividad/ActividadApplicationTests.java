package pa.actividad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * Pruebas de contexto de la aplicacion Spring Boot.
 *
 * @author Ivan Andres Penaloza Quintero - 20242020219
 * @author Jeronimo Cubillos Gomez - 20242020282
 */
@SpringBootTest
class ActividadApplicationTests {

    /**
     * Verifica que el contexto de Spring Boot carga correctamente.
     */
    @Test
    void contextLoads() {
    }
}

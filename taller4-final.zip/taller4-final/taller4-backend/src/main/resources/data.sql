INSERT INTO actividad (titulo, descripcion, fecha_inicio, fecha_fin, tipo, id_quehacer, id_tutor, id_hijo)
VALUES ('Lavar ropa', 'Lavar y tender la ropa del fin de semana', '2026-05-01', '2026-05-02', 'Fisica', 1, 1, 1);

INSERT INTO actividad (titulo, descripcion, fecha_inicio, fecha_fin, tipo, id_quehacer, id_tutor, id_hijo)
VALUES ('Ordenar cuarto', 'Organizar y limpiar la habitacion completamente', '2026-05-01', '2026-05-03', 'Supervision', 2, 1, 2);

INSERT INTO actividad (titulo, descripcion, fecha_inicio, fecha_fin, tipo, id_quehacer, id_tutor, id_hijo)
VALUES ('Barrer sala', 'Barrer y trapear la sala y el comedor', '2026-05-02', '2026-05-04', 'Fisica', 3, 1, 1);

INSERT INTO actividad (titulo, descripcion, fecha_inicio, fecha_fin, tipo, id_quehacer, id_tutor, id_hijo)
VALUES ('Regar plantas', 'Regar todas las plantas del jardin', '2026-05-03', '2026-05-05', 'Creativa', 4, 2, 3);

INSERT INTO actividad (titulo, descripcion, fecha_inicio, fecha_fin, tipo, id_quehacer, id_tutor, id_hijo)
VALUES ('Lavar platos', 'Lavar los platos despues del almuerzo', '2026-05-04', '2026-05-04', 'Fisica', 1, 2, 2);

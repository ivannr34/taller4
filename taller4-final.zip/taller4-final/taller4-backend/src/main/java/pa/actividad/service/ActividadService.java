package pa.actividad.service;

import pa.actividad.modelo.Actividad;
import pa.actividad.repository.ActividadRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * Servicio que contiene la logica de negocio para la gestion de actividades.
 * <p>
 * Esta capa actua como intermediario entre el controlador y el repositorio,
 * garantizando la separacion de responsabilidades (principio SOLID - SRP).
 * El service devuelve {@link Optional} para que sea el controlador quien
 * decida que tipo de respuesta HTTP enviar segun el resultado.
 * </p>
 *
 * @author Ivan Andres Penaloza Quintero - 20242020219
 * @author Jeronimo Cubillos Gomez - 20242020282
 * @version 1.0
 */
@Service
public class ActividadService {

    /**
     * Repositorio JPA para acceso a datos de actividades.
     */
    private final ActividadRepository repository;

    /**
     * Constructor con inyeccion de dependencia del repositorio.
     *
     * @param repository repositorio de actividades
     */
    public ActividadService(ActividadRepository repository) {
        this.repository = repository;
    }

    /**
     * Crea y persiste una nueva actividad en la base de datos.
     *
     * @param actividad objeto {@link Actividad} con los datos a guardar
     * @return {@link Optional} con la actividad guardada, o vacio si fallo
     */
    public Optional<Actividad> crearActividad(Actividad actividad) {
        try {
            return Optional.of(repository.save(actividad));
        } catch (Exception e) {
            return Optional.empty();
        }
    }

    /**
     * Obtiene la lista completa de todas las actividades registradas.
     *
     * @return lista de {@link Actividad}; vacia si no hay registros
     */
    public List<Actividad> obtenerTodas() {
        return repository.findAll();
    }

    /**
     * Busca una actividad por su identificador unico.
     * <p>
     * Devuelve {@link Optional} vacio si no existe ninguna actividad
     * con ese id, en lugar de lanzar una excepcion o devolver null.
     * El controlador es responsable de manejar el caso vacio.
     * </p>
     *
     * @param id identificador de la actividad
     * @return {@link Optional} con la actividad si existe, o vacio si no
     */
    public Optional<Actividad> obtenerPorId(Long id) {
        return repository.findById(id);
    }

    /**
     * Actualiza todos los campos de una actividad existente.
     * <p>
     * Si no existe la actividad con el id dado, devuelve un
     * {@link Optional} vacio para que el controlador retorne 404.
     * </p>
     *
     * @param id    identificador de la actividad a modificar
     * @param nueva objeto {@link Actividad} con los nuevos valores
     * @return {@link Optional} con la actividad actualizada, o vacio si no existe
     */
    public Optional<Actividad> actualizar(Long id, Actividad nueva) {
        return repository.findById(id).map(act -> {
            act.setTitulo(nueva.getTitulo());
            act.setDescripcion(nueva.getDescripcion());
            act.setFechaInicio(nueva.getFechaInicio());
            act.setFechaFin(nueva.getFechaFin());
            act.setTipo(nueva.getTipo());
            act.setIdQuehacer(nueva.getIdQuehacer());
            act.setIdTutor(nueva.getIdTutor());
            act.setIdHijo(nueva.getIdHijo());
            return repository.save(act);
        });
    }

    /**
     * Elimina una actividad de la base de datos por su id.
     * <p>
     * Devuelve true si existia y fue eliminada, false si no existia.
     * </p>
     *
     * @param id identificador de la actividad a eliminar
     * @return true si se elimino, false si no existia
     */
    public boolean eliminar(Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return true;
        }
        return false;
    }
}

package pa.actividad.control;

import pa.actividad.modelo.Actividad;
import pa.actividad.service.ActividadService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

/**
 * Controlador de vistas que maneja la renderizacion dinamica de HTML
 * usando Thymeleaf.
 * <p>
 * A diferencia de {@link ControlActividad} que usa {@code @RestController}
 * y devuelve JSON, este controlador usa {@code @Controller} y devuelve
 * el nombre de una plantilla HTML que Thymeleaf renderiza con datos
 * inyectados en el modelo.
 * </p>
 *
 * @author Ivan Andres Penaloza Quintero - 20242020219
 * @author Jeronimo Cubillos Gomez - 20242020282
 * @version 1.0
 * @see ControlActividad
 */
@Controller
@RequestMapping("/vista")
public class ControlVista {

    /**
     * Servicio con la logica de negocio de actividades.
     */
    private final ActividadService service;

    /**
     * Constructor con inyeccion de dependencia del servicio.
     *
     * @param service servicio de actividades
     */
    public ControlVista(ActividadService service) {
        this.service = service;
    }

    /**
     * Renderiza la vista con la lista de todas las actividades.
     * <p>
     * Inyecta la lista en el modelo bajo la clave "actividades"
     * para que Thymeleaf la pueda recorrer en el HTML.
     * </p>
     *
     * @param model modelo de datos que se pasa a la vista Thymeleaf
     * @return nombre de la plantilla "actividades" (actividades.html)
     */
    @GetMapping("/actividades")
    public String listarActividades(Model model) {
        model.addAttribute("actividades", service.obtenerTodas());
        return "actividades";
    }

    /**
     * Renderiza la vista con el detalle de una actividad por su id.
     * <p>
     * Si la actividad existe, la inyecta en el modelo. Si no existe,
     * inyecta un mensaje de error. El controlador decide que mostrar
     * segun el Optional devuelto por el service.
     * </p>
     *
     * @param id    identificador de la actividad a mostrar
     * @param model modelo de datos que se pasa a la vista Thymeleaf
     * @return nombre de la plantilla "detalle" (detalle.html)
     */
    @GetMapping("/actividades/{id}")
    public String detalleActividad(@PathVariable Long id, Model model) {
        Optional<Actividad> resultado = service.obtenerPorId(id);
        if (resultado.isPresent()) {
            model.addAttribute("actividad", resultado.get());
            model.addAttribute("error", null);
        } else {
            model.addAttribute("actividad", null);
            model.addAttribute("error", "No se encontro ninguna actividad con el id: " + id);
        }
        return "detalle";
    }
}

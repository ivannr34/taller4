package pa.actividad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Clase principal de la aplicacion Spring Boot para el Taller 4.
 * <p>
 * Gestiona los quehaceres del hogar y sus actividades,
 * permitiendo el seguimiento entre tutores e hijos.
 * </p>
 *
 * @author Ivan Andres Penaloza Quintero - 20242020219
 * @author Jeronimo Cubillos Gomez - 20242020282
 * @version 1.0
 */
@SpringBootApplication
public class ActividadApplication {

    /**
     * Metodo de entrada de la aplicacion.
     *
     * @param args argumentos de linea de comandos
     */
    public static void main(String[] args) {
        SpringApplication.run(ActividadApplication.class, args);
    }
}

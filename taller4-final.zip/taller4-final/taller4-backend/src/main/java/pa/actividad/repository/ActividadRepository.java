package pa.actividad.repository;

import pa.actividad.modelo.Actividad;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Repositorio JPA para la entidad {@link Actividad}.
 * <p>
 * Provee operaciones CRUD estandar sobre la base de datos H2 en memoria,
 * mediante la interfaz {@link JpaRepository}. Las operaciones SQL estan
 * completamente desacopladas de la logica de negocio, siguiendo los
 * principios SOLID de separacion de responsabilidades.
 * </p>
 *
 * @author Ivan Andres Penaloza Quintero - 20242020219
 * @author Jeronimo Cubillos Gomez - 20242020282
 * @version 1.0
 */
@Repository
public interface ActividadRepository extends JpaRepository<Actividad, Long> {
}

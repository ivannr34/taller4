package pa.actividad.modelo;

import jakarta.persistence.*;
import java.time.LocalDate;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

/**
 * Entidad que representa una Actividad dentro de un quehacer del hogar.
 * <p>
 * Una actividad es una labor especifica asignada por un tutor a un hijo,
 * dentro del contexto de un quehacer domestico (ej: planchar ropa, dentro
 * del quehacer "ropa").
 * </p>
 *
 * @author Ivan Andres Penaloza Quintero - 20242020219
 * @author Jeronimo Cubillos Gomez - 20242020282
 * @version 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "actividad")
public class Actividad {

    /**
     * Identificador unico de la actividad, generado automaticamente.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Titulo descriptivo de la actividad (ej: "Planchar ropa del fin de semana").
     */
    private String titulo;

    /**
     * Descripcion detallada de lo que implica la actividad.
     */
    private String descripcion;

    /**
     * Fecha en la que inicia la actividad.
     */
    @Column(name = "fecha_inicio")
    private LocalDate fechaInicio;

    /**
     * Fecha limite para completar la actividad.
     */
    @Column(name = "fecha_fin")
    private LocalDate fechaFin;

    /**
     * Tipo de actividad. Valores posibles: Fisica, Acompanamiento,
     * Supervision, Creativa, entre otros.
     */
    private String tipo;

    /**
     * Identificador del quehacer al que pertenece esta actividad
     * (ej: quehacer "Ropa" tiene id=1).
     */
    @Column(name = "id_quehacer")
    private Long idQuehacer;

    /**
     * Identificador del tutor que asigna y administra esta actividad.
     */
    @Column(name = "id_tutor")
    private Long idTutor;

    /**
     * Identificador del hijo responsable de ejecutar esta actividad.
     */
    @Column(name = "id_hijo")
    private Long idHijo;
}

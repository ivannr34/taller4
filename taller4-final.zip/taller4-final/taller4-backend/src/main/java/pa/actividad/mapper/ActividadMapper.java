package pa.actividad.mapper;

import pa.actividad.modelo.Actividad;
import pa.actividad.modelo.ActividadResponse;
import org.springframework.stereotype.Component;

/**
 * Mapper encargado de convertir entre la entidad {@link Actividad}
 * y el DTO {@link ActividadResponse}.
 * <p>
 * Siguiendo el principio de responsabilidad unica (SOLID - SRP),
 * esta clase tiene un unico proposito: transformar objetos de un
 * tipo a otro. Ni la entidad ni el DTO saben como convertirse —
 * esa responsabilidad pertenece exclusivamente al Mapper.
 * </p>
 *
 * @author Ivan Andres Penaloza Quintero - 20242020219
 * @author Jeronimo Cubillos Gomez - 20242020282
 * @version 1.0
 */
@Component
public class ActividadMapper {

    /**
     * Convierte una entidad {@link Actividad} a un DTO {@link ActividadResponse}.
     * <p>
     * Se usa cuando el controlador va a enviar datos al frontend —
     * nunca se expone la entidad directamente.
     * </p>
     *
     * @param actividad entidad a convertir
     * @return DTO con los datos de la actividad
     */
    public ActividadResponse toResponse(Actividad actividad) {
        ActividadResponse response = new ActividadResponse();
        response.setId(actividad.getId());
        response.setTitulo(actividad.getTitulo());
        response.setDescripcion(actividad.getDescripcion());
        response.setFechaInicio(actividad.getFechaInicio());
        response.setFechaFin(actividad.getFechaFin());
        response.setTipo(actividad.getTipo());
        response.setIdQuehacer(actividad.getIdQuehacer());
        response.setIdTutor(actividad.getIdTutor());
        response.setIdHijo(actividad.getIdHijo());
        return response;
    }

    /**
     * Convierte un DTO {@link ActividadResponse} a una entidad {@link Actividad}.
     * <p>
     * Se usa cuando el controlador recibe datos del frontend y necesita
     * persistirlos en la base de datos.
     * </p>
     *
     * @param response DTO recibido del frontend
     * @return entidad lista para persistir
     */
    public Actividad toEntity(ActividadResponse response) {
        Actividad actividad = new Actividad();
        actividad.setId(response.getId());
        actividad.setTitulo(response.getTitulo());
        actividad.setDescripcion(response.getDescripcion());
        actividad.setFechaInicio(response.getFechaInicio());
        actividad.setFechaFin(response.getFechaFin());
        actividad.setTipo(response.getTipo());
        actividad.setIdQuehacer(response.getIdQuehacer());
        actividad.setIdTutor(response.getIdTutor());
        actividad.setIdHijo(response.getIdHijo());
        return actividad;
    }
}

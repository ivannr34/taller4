package pa.actividad.control;

import pa.actividad.modelo.Actividad;
import pa.actividad.service.ActividadService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

/**
 * Controlador REST que expone los endpoints JSON del microservicio de Actividades.
 * <p>
 * Usa la anotacion {@code @RestController} para indicar que todas las respuestas
 * se serializan directamente a JSON. Es el responsable de traducir el resultado
 * del {@link ActividadService} (que devuelve {@link Optional}) al codigo HTTP
 * correspondiente: 200 OK si hay resultado, 404 Not Found si el Optional esta vacio,
 * 500 si ocurrio un error inesperado.
 * </p>
 *
 * @author Ivan Andres Penaloza Quintero - 20242020219
 * @author Jeronimo Cubillos Gomez - 20242020282
 * @version 1.0
 * @see ControlVista
 */
@RestController
@RequestMapping("/api/actividad")
@CrossOrigin(origins = "*")
public class ControlActividad {

    /**
     * Servicio con la logica de negocio de actividades.
     */
    private final ActividadService service;

    /**
     * Constructor con inyeccion de dependencia del servicio.
     *
     * @param service servicio de actividades
     */
    public ControlActividad(ActividadService service) {
        this.service = service;
    }

    /**
     * Inserta una nueva actividad en la base de datos.
     *
     * @param actividad objeto {@link Actividad} deserializado del cuerpo JSON
     * @return 200 con la actividad creada, o 500 si fallo el guardado
     */
    @PostMapping
    public ResponseEntity<?> crear(@RequestBody Actividad actividad) {
        Optional<Actividad> resultado = service.crearActividad(actividad);
        if (resultado.isPresent()) {
            return ResponseEntity.ok(resultado.get());
        }
        return ResponseEntity.internalServerError()
                .body("Error al guardar la actividad en la base de datos.");
    }

    /**
     * Consulta y retorna todas las actividades registradas.
     *
     * @return 200 con lista de actividades en JSON
     */
    @GetMapping
    public ResponseEntity<List<Actividad>> listar() {
        return ResponseEntity.ok(service.obtenerTodas());
    }

    /**
     * Consulta una actividad especifica por su id.
     *
     * @param id identificador de la actividad
     * @return 200 con la actividad, o 404 con mensaje si no existe
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> obtener(@PathVariable Long id) {
        Optional<Actividad> resultado = service.obtenerPorId(id);
        if (resultado.isPresent()) {
            return ResponseEntity.ok(resultado.get());
        }
        return ResponseEntity.status(404)
                .body("No se encontro ninguna actividad con el id: " + id);
    }

    /**
     * Modifica una actividad existente con los nuevos datos recibidos.
     * <p>La prueba de este endpoint se puede realizar usando Postman.</p>
     *
     * @param id        identificador de la actividad a modificar
     * @param actividad objeto con los datos actualizados
     * @return 200 con la actividad modificada, o 404 con mensaje si no existe
     */
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizar(@PathVariable Long id,
                                         @RequestBody Actividad actividad) {
        Optional<Actividad> resultado = service.actualizar(id, actividad);
        if (resultado.isPresent()) {
            return ResponseEntity.ok(resultado.get());
        }
        return ResponseEntity.status(404)
                .body("No se encontro ninguna actividad con el id: " + id);
    }

    /**
     * Elimina una actividad de la base de datos por su id.
     *
     * @param id identificador de la actividad a eliminar
     * @return 204 No Content si se elimino, o 404 con mensaje si no existia
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id) {
        boolean eliminado = service.eliminar(id);
        if (eliminado) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.status(404)
                .body("No se encontro ninguna actividad con el id: " + id);
    }
}

package pa.actividad.control;

import pa.actividad.modelo.Actividad;
import pa.actividad.modelo.ActividadResponse;
import pa.actividad.service.ActividadService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Controlador REST que expone los endpoints JSON del microservicio de Actividades.
 * <p>
 * Usa {@code @RestController} para responder con JSON. Recibe entidades
 * {@link Actividad} del service pero las convierte a {@link ActividadResponse}
 * antes de enviarlas al frontend, siguiendo el principio de separacion de
 * responsabilidades: la entidad es para la base de datos, el DTO es para
 * la comunicacion con el cliente.
 * </p>
 *
 * @author Ivan Andres Penaloza Quintero - 20242020219
 * @author Jeronimo Cubillos Gomez - 20242020282
 * @version 1.0
 */
@RestController
@RequestMapping("/api/actividad")
@CrossOrigin(origins = "*")
public class ControlActividad {

    /** Servicio con la logica de negocio de actividades. */
    private final ActividadService service;

    /**
     * Constructor con inyeccion de dependencia del servicio.
     *
     * @param service servicio de actividades
     */
    public ControlActividad(ActividadService service) {
        this.service = service;
    }

    /**
     * Inserta una nueva actividad en la base de datos.
     *
     * @param actividad entidad {@link Actividad} recibida del frontend en JSON
     * @return 200 con {@link ActividadResponse}, o 500 si fallo el guardado
     */
    @PostMapping
    public ResponseEntity<?> crear(@RequestBody Actividad actividad) {
        Optional<Actividad> resultado = service.crearActividad(actividad);
        if (resultado.isPresent()) {
            return ResponseEntity.ok(new ActividadResponse(resultado.get()));
        }
        return ResponseEntity.internalServerError()
                .body("Error al guardar la actividad en la base de datos.");
    }

    /**
     * Consulta y retorna todas las actividades como lista de DTOs.
     *
     * @return 200 con lista de {@link ActividadResponse} en JSON
     */
    @GetMapping
    public ResponseEntity<List<ActividadResponse>> listar() {
        List<ActividadResponse> respuesta = service.obtenerTodas()
                .stream()
                .map(ActividadResponse::new)
                .collect(Collectors.toList());
        return ResponseEntity.ok(respuesta);
    }

    /**
     * Consulta una actividad por su id y la retorna como DTO.
     *
     * @param id identificador de la actividad
     * @return 200 con {@link ActividadResponse}, o 404 con mensaje si no existe
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> obtener(@PathVariable Long id) {
        Optional<Actividad> resultado = service.obtenerPorId(id);
        if (resultado.isPresent()) {
            return ResponseEntity.ok(new ActividadResponse(resultado.get()));
        }
        return ResponseEntity.status(404)
                .body("No se encontro ninguna actividad con el id: " + id);
    }

    /**
     * Modifica una actividad existente y retorna el DTO actualizado.
     *
     * @param id        identificador de la actividad a modificar
     * @param actividad entidad con los datos actualizados
     * @return 200 con {@link ActividadResponse}, o 404 si no existe
     */
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizar(@PathVariable Long id,
                                         @RequestBody Actividad actividad) {
        Optional<Actividad> resultado = service.actualizar(id, actividad);
        if (resultado.isPresent()) {
            return ResponseEntity.ok(new ActividadResponse(resultado.get()));
        }
        return ResponseEntity.status(404)
                .body("No se encontro ninguna actividad con el id: " + id);
    }

    /**
     * Elimina una actividad por su id.
     *
     * @param id identificador de la actividad a eliminar
     * @return 204 No Content si se elimino, o 404 si no existia
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id) {
        boolean eliminado = service.eliminar(id);
        if (eliminado) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.status(404)
                .body("No se encontro ninguna actividad con el id: " + id);
    }
}

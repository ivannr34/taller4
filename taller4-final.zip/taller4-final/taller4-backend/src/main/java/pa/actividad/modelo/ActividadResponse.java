package pa.actividad.modelo;

import java.time.LocalDate;

/**
 * Clase DTO (Data Transfer Object) para la respuesta al frontend.
 * <p>
 * Contiene los mismos atributos que {@link Actividad} pero sin anotaciones
 * de persistencia. Su unico proposito es transferir datos al cliente.
 * La conversion entre entidad y DTO la realiza {@link pa.actividad.mapper.ActividadMapper}.
 * </p>
 *
 * @author Ivan Andres Penaloza Quintero - 20242020219
 * @author Jeronimo Cubillos Gomez - 20242020282
 * @version 1.0
 */
public class ActividadResponse {

    /** Identificador unico de la actividad. */
    private Long id;
    /** Titulo de la actividad. */
    private String titulo;
    /** Descripcion detallada de la actividad. */
    private String descripcion;
    /** Fecha de inicio. */
    private LocalDate fechaInicio;
    /** Fecha de terminacion. */
    private LocalDate fechaFin;
    /** Tipo: Fisica, Acompanamiento, Supervision, Creativa. */
    private String tipo;
    /** ID del quehacer al que pertenece. */
    private Long idQuehacer;
    /** ID del tutor que asigna la actividad. */
    private Long idTutor;
    /** ID del hijo responsable. */
    private Long idHijo;

    /** Constructor vacio requerido para serializacion JSON. */
    public ActividadResponse() {}

    /** @return id */ public Long getId() { return id; }
    /** @param id id a asignar */ public void setId(Long id) { this.id = id; }
    /** @return titulo */ public String getTitulo() { return titulo; }
    /** @param titulo titulo */ public void setTitulo(String titulo) { this.titulo = titulo; }
    /** @return descripcion */ public String getDescripcion() { return descripcion; }
    /** @param descripcion descripcion */ public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    /** @return fechaInicio */ public LocalDate getFechaInicio() { return fechaInicio; }
    /** @param fechaInicio fecha inicio */ public void setFechaInicio(LocalDate fechaInicio) { this.fechaInicio = fechaInicio; }
    /** @return fechaFin */ public LocalDate getFechaFin() { return fechaFin; }
    /** @param fechaFin fecha fin */ public void setFechaFin(LocalDate fechaFin) { this.fechaFin = fechaFin; }
    /** @return tipo */ public String getTipo() { return tipo; }
    /** @param tipo tipo */ public void setTipo(String tipo) { this.tipo = tipo; }
    /** @return idQuehacer */ public Long getIdQuehacer() { return idQuehacer; }
    /** @param idQuehacer id quehacer */ public void setIdQuehacer(Long idQuehacer) { this.idQuehacer = idQuehacer; }
    /** @return idTutor */ public Long getIdTutor() { return idTutor; }
    /** @param idTutor id tutor */ public void setIdTutor(Long idTutor) { this.idTutor = idTutor; }
    /** @return idHijo */ public Long getIdHijo() { return idHijo; }
    /** @param idHijo id hijo */ public void setIdHijo(Long idHijo) { this.idHijo = idHijo; }
}

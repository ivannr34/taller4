package pa.actividad.modelo;

import java.time.LocalDate;

/**
 * Clase DTO (Data Transfer Object) para la respuesta al frontend.
 * <p>
 * Esta clase contiene los mismos atributos que {@link Actividad}, pero
 * no tiene anotaciones de persistencia ({@code @Entity}, {@code @Table}).
 * Su unico proposito es transferir datos entre el backend y el frontend,
 * siguiendo el principio de separacion de responsabilidades (SOLID - SRP):
 * la entidad se encarga de la persistencia, y el DTO se encarga de
 * la comunicacion con el cliente.
 * </p>
 * <p>
 * Ejemplo de utilidad: en un login, la entidad Usuario tendria la
 * contrasena, pero el DTO de respuesta no la incluiria para no
 * exponerla al frontend.
 * </p>
 *
 * @author Ivan Andres Penaloza Quintero - 20242020219
 * @author Jeronimo Cubillos Gomez - 20242020282
 * @version 1.0
 */
public class ActividadResponse {

    /** Identificador unico de la actividad. */
    private Long id;

    /** Titulo de la actividad. */
    private String titulo;

    /** Descripcion detallada de la actividad. */
    private String descripcion;

    /** Fecha de inicio de la actividad. */
    private LocalDate fechaInicio;

    /** Fecha de terminacion de la actividad. */
    private LocalDate fechaFin;

    /** Tipo de actividad: Fisica, Acompanamiento, Supervision, Creativa. */
    private String tipo;

    /** Identificador del quehacer al que pertenece la actividad. */
    private Long idQuehacer;

    /** Identificador del tutor que asigna la actividad. */
    private Long idTutor;

    /** Identificador del hijo responsable de la actividad. */
    private Long idHijo;

    /**
     * Constructor vacio requerido para serializacion JSON.
     */
    public ActividadResponse() {}

    /**
     * Constructor que convierte una entidad {@link Actividad} en un DTO.
     * <p>
     * Este es el constructor principal — recibe la entidad y copia
     * sus atributos, sin exponer informacion sensible al frontend.
     * </p>
     *
     * @param actividad entidad de la cual se extraen los datos
     */
    public ActividadResponse(Actividad actividad) {
        this.id = actividad.getId();
        this.titulo = actividad.getTitulo();
        this.descripcion = actividad.getDescripcion();
        this.fechaInicio = actividad.getFechaInicio();
        this.fechaFin = actividad.getFechaFin();
        this.tipo = actividad.getTipo();
        this.idQuehacer = actividad.getIdQuehacer();
        this.idTutor = actividad.getIdTutor();
        this.idHijo = actividad.getIdHijo();
    }

    /** @return id de la actividad */
    public Long getId() { return id; }
    /** @param id id a asignar */
    public void setId(Long id) { this.id = id; }

    /** @return titulo */
    public String getTitulo() { return titulo; }
    /** @param titulo titulo a asignar */
    public void setTitulo(String titulo) { this.titulo = titulo; }

    /** @return descripcion */
    public String getDescripcion() { return descripcion; }
    /** @param descripcion descripcion a asignar */
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    /** @return fecha de inicio */
    public LocalDate getFechaInicio() { return fechaInicio; }
    /** @param fechaInicio fecha de inicio a asignar */
    public void setFechaInicio(LocalDate fechaInicio) { this.fechaInicio = fechaInicio; }

    /** @return fecha de terminacion */
    public LocalDate getFechaFin() { return fechaFin; }
    /** @param fechaFin fecha de fin a asignar */
    public void setFechaFin(LocalDate fechaFin) { this.fechaFin = fechaFin; }

    /** @return tipo de actividad */
    public String getTipo() { return tipo; }
    /** @param tipo tipo a asignar */
    public void setTipo(String tipo) { this.tipo = tipo; }

    /** @return id del quehacer */
    public Long getIdQuehacer() { return idQuehacer; }
    /** @param idQuehacer id del quehacer a asignar */
    public void setIdQuehacer(Long idQuehacer) { this.idQuehacer = idQuehacer; }

    /** @return id del tutor */
    public Long getIdTutor() { return idTutor; }
    /** @param idTutor id del tutor a asignar */
    public void setIdTutor(Long idTutor) { this.idTutor = idTutor; }

    /** @return id del hijo */
    public Long getIdHijo() { return idHijo; }
    /** @param idHijo id del hijo a asignar */
    public void setIdHijo(Long idHijo) { this.idHijo = idHijo; }
}
